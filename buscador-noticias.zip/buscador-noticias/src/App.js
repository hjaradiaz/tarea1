import React, { Component } from "react";
// import logo from './logo.svg';

import Header from "./components/Header";
import Formulario from "./components/Formulario";
import ListaNoticias from "./components/ListaNoticias";

class App extends Component {
  constructor(props){
    super(props);
    this.state = {
      listaNoticias: []
    }
  }

  componentDidMount() {
    this.consutalNoticia();
  }

  consutalNoticia = async (categoria='general') => {
    const urlApi = `${process.env.REACT_APP_URL_API}/top-headlines?country=mx&category=${categoria}&apiKey=${process.env.REACT_APP_KEY}`
    const respuesta = await fetch(urlApi);
    const noticas = await respuesta.json();
    this.setState({listaNoticias: noticas.articles});
  }

  render() {
    return (
      <div className="bg-dark">
        <Header />
        <section className="container bg-light">
          <h4 className="text-center">Ecuentra noticias por categoria</h4>
          <Formulario consutalNoticia={this.consutalNoticia}/>
          <ListaNoticias listaNoticias={this.state.listaNoticias}/>
        </section>
      </div>
    );
  }
}

export default App;
