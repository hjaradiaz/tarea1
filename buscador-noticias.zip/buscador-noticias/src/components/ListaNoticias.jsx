import React, { Component } from "react";

import Noticias from "./Notica";

class ListaNoticias extends Component {
  render() {
    const { listaNoticias } = this.props;
    return (
      <div className="card-columns">
        {listaNoticias.map((notica, index) => (
          <Noticias key={index} noticia={notica} />
        ))}
      </div>
    );
  }
}

export default ListaNoticias;
