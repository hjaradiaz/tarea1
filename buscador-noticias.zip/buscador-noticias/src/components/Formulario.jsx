import React, { Component } from "react";
import Select from "react-select";

// business entertainment general health science sports technology

const options = [
  { value: "general", label: "General" },
  { value: "business", label: "Negocios" },
  { value: "entertainment", label: "Entretenimiento" },
  { value: "health", label: "Salud" },
  { value: "science", label: "Ciencia" },
  { value: "sports", label: "Deporte" },
  { value: "technology", label: "Tecnologia" },
];

class Formulario extends Component {

    state= {
        opcionSeleccionada: { value: "general", label: "General" }
    }

  handleChange = (datoSeleccionado) => {
    console.log(datoSeleccionado);
    this.setState({opcionSeleccionada: datoSeleccionado})
    this.props.consutalNoticia(datoSeleccionado.value);
  };

  render() {
    return (
      <form>
        <div className="form-row justify-content-center">
          <div className="form-group col-md-4">
            <Select
              placeholder={"Seleciona la categoria"}
              options={options}
              onChange={this.handleChange}
              value={this.state.opcionSeleccionada}
            />
          </div>
        </div>
      </form>
    );
  }
}

export default Formulario;
