import React, { Component } from "react";
import logo from "../logo.svg";

class Notica extends Component {
  render() {
    const { urlToImage, url, title, description } = this.props.noticia;
    const urlAlternativa = urlToImage ? urlToImage : logo;
    return (
      <div className="card" style={{ maxWidth: "18em" }}>
        <img className="card-img-top" src={urlAlternativa} alt={title} />
        <div className="card-body">
          <h5 className="card-title">{title}</h5>
          <p className="card-text">{description}</p>
        </div>
        <div className="card-footer">
          <a
            href={url}
            target={"_blank"}
            rel="noopener noreferrer"
            className="btn btn-primary btn-lg active"
          >
            {" "}
            Ver Noticia
          </a>
        </div>
      </div>
    );
  }
}

export default Notica;
