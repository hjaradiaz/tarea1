export const environment = {
  production: true,
  urlApi : 'https://localhost:44372/api/'
};
