import { Component, OnInit } from '@angular/core';
import { AutoService } from 'src/app/Services/auto.service';
import { NgForm } from '@angular/forms';
import { AutoDataModel } from 'src/app/Modelo/auto-data.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-auto-nuevo',
  templateUrl: './auto-nuevo.component.html',
  styleUrls: ['./auto-nuevo.component.css']
})
export class AutoNuevoComponent implements OnInit {
  ListaMarcas : []

  auto : AutoDataModel = {
    id : 0,
    placa : "",
    marca : 0,
    modelo : "",
    descripcion : ""
  }

  constructor(private autoService : AutoService) { }

  ngOnInit(): void {
    this.obtenerMArcas();
  }

  obtenerMArcas(){
    this.autoService.getMarcas().subscribe(
      (resultado) => {this.ListaMarcas = resultado; console.log(resultado)},
      (error) => {console.log(error)}
    );
  }

  grabarNG(forma: NgForm) {    
    console.log(forma);
    this.autoService.guardar(this.auto).subscribe(
      (resultado) => {
        console.log(resultado)
      },
      (error) => {console.log(error)}
    );
  }

}
