import { Component, OnInit } from '@angular/core';
import { PersonaDataModel } from '../../Modelo/persona-data.model';
import { v4 as uuidv4 } from 'uuid';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  Nombre : String = ""
  Amigos : String[] = ["Carlos", "Alex", "Jafet", "Luis"]
  Persona : PersonaDataModel = new PersonaDataModel();

  agregarAmigo(nombre){
    this.Amigos.push(nombre);
    
    return false;
  }

  eliminarAmigoPadre(nombre){
    console.log("Eliminar desde Padre:" + nombre);
    for(let i=0; i<this.Amigos.length; i++){
      if(nombre == this.Amigos[i])
        this.Amigos.splice(i,1)
    }
  }

  constructor() { }

  ngOnInit(): void {
    this.Persona.id = uuidv4()
    this.Persona.nombre = "Harold"
    this.Persona.edad = 20

  }

}
