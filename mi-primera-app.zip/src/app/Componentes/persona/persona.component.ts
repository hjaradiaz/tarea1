import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { PersonaDataModel } from 'src/app/Modelo/persona-data.model';

@Component({
  selector: 'app-persona',
  templateUrl: './persona.component.html',
  styleUrls: ['./persona.component.css']
})
export class PersonaComponent implements OnInit {

  @Input()
  Nombre : String =""

  @Input()
  Persona : PersonaDataModel

  @Output()
  eliminar = new EventEmitter<string>()

  eliminarAmigo(nombre){
    this.eliminar.emit(nombre);
  }

  constructor() { }

  ngOnInit(): void {
    console.log("Id: " + this.Persona.id)
    console.log("Persona: " + this.Persona.nombre)
    console.log("Edad: " + this.Persona.edad)    
  }

}
