import { Component, OnInit } from '@angular/core';
import { error } from 'protractor';
import { AutoService } from 'src/app/Services/auto.service';

@Component({
  selector: 'app-auto',
  templateUrl: './auto.component.html',
  styleUrls: ['./auto.component.css']
})
export class AutoComponent implements OnInit {

  ListaAutos : []
  ListaMarcas : []

  constructor(private autoService : AutoService) { }

  ngOnInit(): void {
    this.obtenerAutos("",0,"");
    this.obtenerMArcas();
  }

  buscar(placa, marca, modelo){
    console.log("filtros");
    this.obtenerAutos(placa,marca,modelo);
    return false;
  }

  obtenerAutos(placa, marca, modelo){
    this.autoService.getAllAutos(placa,marca,modelo).subscribe(
      (resultado) => {this.ListaAutos = resultado; console.log(resultado)},
      (error) => {console.log(error)}
    );
  }

  obtenerMArcas(){
    this.autoService.getMarcas().subscribe(
      (resultado) => {this.ListaMarcas = resultado; console.log(resultado)},
      (error) => {console.log(error)}
    );
  }

}
