import { Component, OnInit } from '@angular/core';
import { CommentService } from 'src/app/Services/comment.service';

@Component({
  selector: 'app-comentario',
  templateUrl: './comentario.component.html',
  styleUrls: ['./comentario.component.css']
})
export class ComentarioComponent implements OnInit {

  ListaComentarios : []

  constructor(private commentService : CommentService) { }

  ngOnInit(): void {
      this.commentService.listarComentarios().subscribe(
        (resultado) => { this.ListaComentarios = resultado},
        (error) => {console.log(error)},
        () => {console.log("se ejecuto el metodo Listar Comentarios")}
      );
  }

}
