import { Component, OnInit } from '@angular/core';
import { PublicacionService } from 'src/app/Services/publicacion.service';


@Component({
  selector: 'app-publicacion',
  templateUrl: './publicacion.component.html',
  styleUrls: ['./publicacion.component.css']
})
export class PublicacionComponent implements OnInit {

  Publicaciones : []

  constructor(private pulicacionService : PublicacionService) { }

  ngOnInit(): void {
    this.pulicacionService.listarPosts().subscribe(
      (data) => {this.Publicaciones = data; console.log(data)},
      (err) => { console.log(err)},
      () => {});
  }



}
