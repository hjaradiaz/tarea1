export class AutoDataModel{

    id : number
    placa : String
    marca : Number
    modelo : String
    descripcion : String

    constructor() {  
        this.id = 0
        this.placa = ""
        this.marca = 0
        this.modelo = ""
        this.descripcion = ""
    }
}