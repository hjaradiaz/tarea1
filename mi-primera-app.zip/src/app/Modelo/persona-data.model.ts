export class PersonaDataModel{

    id : String
    nombre : String
    edad : Number

    constructor() {  
        
    }
}