import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { environment } from 'src/environments/environment.prod';
import { Observable } from 'rxjs';
import { AutoDataModel } from '../Modelo/auto-data.model';

@Injectable({
  providedIn: 'root'
})
export class AutoService {

  constructor(private http : HttpClient) { }

  getAllAutos(placa : string, marca: number, modelo : string) : Observable<any>{
    placa = placa == "" ? "-" : placa
    modelo = modelo == "" ? "-" : modelo
    return this.http.get(environment.urlApi + "auto/getall/"+placa+"/"+marca.toString()+"/"+modelo)
  }

  getMarcas() : Observable<any>{    
    return this.http.get(environment.urlApi + "auto/getmarcas")
  }

  guardar(autoInfo : AutoDataModel) : Observable<any>{

    const cadena = JSON.stringify(autoInfo);

    let hd = new HttpHeaders();
    hd = hd.set("Content-Type", "application/json");

    return this.http.post(environment.urlApi + "auto/guardar", cadena, {headers : hd});

}
}
