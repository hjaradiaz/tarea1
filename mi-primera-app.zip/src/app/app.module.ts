import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule} from '@angular/common/http';
import { RouterModule, Route} from '@angular/router'
import { FormsModule, ReactiveFormsModule} from '@angular/forms';


import { AppComponent } from './app.component';
import { HomeComponent } from './Componentes/home/home.component';
import { PersonaComponent } from './Componentes/persona/persona.component';
import { PublicacionComponent } from './Componentes/publicacion/publicacion.component';
import { PersonaService } from './Services/persona.service';
import { PublicacionService } from './Services/publicacion.service';
import { AboutComponent } from './Componentes/about/about.component';
import { SidebarComponent } from './Componentes/sidebar/sidebar.component';
import { CommentService } from './Services/comment.service';
import { ComentarioComponent } from './Componentes/comentario/comentario.component';
import { AutoComponent } from './Componentes/auto/auto.component';
import { AutoNuevoComponent } from './Componentes/auto-nuevo/auto-nuevo.component';

const routes : Route[] = [
  {path: '', component : HomeComponent},
  {path: 'publicacion', component : PublicacionComponent},
  {path: 'about', component : AboutComponent},
  {path: 'comentarios', component : ComentarioComponent},
  {path: 'auto/listar', component : AutoComponent},
  {path: 'auto/nuevo/:id', component : AutoNuevoComponent},
  {path: 'auto/nuevo', component : AutoNuevoComponent},
]

@NgModule({
  declarations: [ 
    AppComponent,
    HomeComponent, 
    PersonaComponent,
    PublicacionComponent,
    SidebarComponent,
    ComentarioComponent,
    AutoComponent,
    AutoNuevoComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(
      routes
    ),
  ],
  providers: [PersonaService, PublicacionService, CommentService],
  bootstrap: [AppComponent]
})
export class AppModule { }
