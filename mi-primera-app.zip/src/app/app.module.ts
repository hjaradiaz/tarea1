import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule} from '@angular/common/http';
import { RouterModule, Route} from '@angular/router'

import { AppComponent } from './app.component';
import { HomeComponent } from './Componentes/home/home.component';
import { PersonaComponent } from './Componentes/persona/persona.component';
import { PublicacionComponent } from './Componentes/publicacion/publicacion.component';
import { PersonaService } from './Services/persona.service';
import { PublicacionService } from './Services/publicacion.service';
import { AboutComponent } from './Componentes/about/about.component';
import { SidebarComponent } from './Componentes/sidebar/sidebar.component';
import { CommentService } from './Services/comment.service';
import { ComentarioComponent } from './Componentes/comentario/comentario.component';

const routes : Route[] = [
  {path: '', component : HomeComponent},
  {path: 'publicacion', component : PublicacionComponent},
  {path: 'about', component : AboutComponent},
  {path: 'comentarios', component : ComentarioComponent},
]

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    PersonaComponent,
    PublicacionComponent,
    SidebarComponent,
    ComentarioComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    RouterModule.forRoot(
      routes
    ),
  ],
  providers: [PersonaService, PublicacionService, CommentService],
  bootstrap: [AppComponent]
})
export class AppModule { }
