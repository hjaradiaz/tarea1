import FontAwesomeClases from "./fontAwesomeClases";
import shuffle from 'lodash.shuffle';
const NUMERO_DE_CARTAS = 20;

export default () => {
  const fontAwesome = FontAwesomeClases();
  let cartas = [];

  while (cartas.length < NUMERO_DE_CARTAS) {
    const index = Math.floor(Math.random() * fontAwesome.length);

    const carta = {
      icono: fontAwesome.splice(index, 1)[0],
      fueAdivinada: false,
    };

    cartas.push(carta);
    cartas.push({...carta});
  }

  return shuffle(cartas);
};
