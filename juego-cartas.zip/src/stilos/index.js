const similar = {
  borderRadius: "5px",
  height: "125px",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  cursor: "pointer",
};

export const stilos = {
  backCard: {
    ...similar,
    background: "#ffb300",
    color: "#000",
  },
  frontCard: {
    ...similar,
    background: "#03dcf4",
    fontSize: "2em",
  },
};
