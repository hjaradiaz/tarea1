import React, { Component } from "react";

import Header from "./components/Header";
import Tablero from "./components/Tablero";

import baraja from "./utils/baraja";

const estadoInicial = {
  baraja: baraja(),
  parejaSeleccionada: [],
  estamosComparando: false,
  numeroDeIntentos: 0,
};

class App extends Component {
  state = { ...estadoInicial };

  reiniciar = () => {
    this.setState({ ...estadoInicial });
  };

  seleccionarCarta = (carta) => {
    /** Validar 3 casos
     * Si estamos comparanado no volteamos las cartas
     * si la carta fue adivinada no volteamos la carta
     * si la carta seleccionada esta en arrelgo de comparación tampoco volteamos la carta
     */

    if (
      this.state.estamosComparando ||
      carta.fueAdivinada ||
      this.state.parejaSeleccionada.indexOf(carta) > -1
    ) {
      return;
    }

    // si la carta no cae en ninguna de las casuisticas,
    // proceder almacer en arreglo compardor.
    const parejaSeleccionada = [...this.state.parejaSeleccionada, carta];
    this.setState({ parejaSeleccionada });

    /**
     * Si el arreglo de parejas selecionadas tiene 2 elementos
     * procedemos comparar si son iguales
     */
    if (parejaSeleccionada.length === 2) {
      this.compararPareja(parejaSeleccionada);
    }
  };

  compararPareja = (arregloComparador) => {
    /** Indicamos que estamos comparando y nos tomaremos un tiempo*/

    this.setState({ ...this.setState, estamosComparando: true });

    setTimeout(() => {
      const [primeraCarta, segundaCarta] = arregloComparador;
      let baraja = this.state.baraja;

      // comparamos si ambas cartas son iguales
      if (primeraCarta.icono === segundaCarta.icono) {
        baraja = baraja.map((carta) => {
          if (carta.icono !== primeraCarta.icono) {
            return carta;
          }
          return { ...carta, fueAdivinada: true };
        });
      }

      this.verificamosSiHayGanador(baraja);

      this.setState({
        baraja: baraja,
        parejaSeleccionada: [],
        estamosComparando: false,
        numeroDeIntentos: this.state.numeroDeIntentos + 1,
      });
    }, 1000);
  };

  verificamosSiHayGanador = (barajaActualiza) => {
    if (barajaActualiza.filter((carta) => !carta.fueAdivinada).length === 0) {
      alert("Ganaste la partida");
    }
  };

  render() {
    return (
      <div className="container">
        <Header
          intentos={this.state.numeroDeIntentos}
          reinciarJuego={this.reiniciar}
        />
        <Tablero
          baraja={this.state.baraja}
          seleccionarCarta={this.seleccionarCarta}
          parejaSeleccionada={this.state.parejaSeleccionada}
        />
      </div>
    );
  }
}

export default App;
