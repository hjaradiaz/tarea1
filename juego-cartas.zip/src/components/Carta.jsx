import React, { Component } from "react";
import ReactCardFlip from "react-card-flip";

import {stilos} from '../stilos/index.js'

class Carta extends Component {
  state = {
    isFlipped: false,
  };
  handleClick = () => {
    this.setState({ isFlipped: !this.state.isFlipped });
  };
  render() {
    const mostramosCarta = this.props.estaSiendoComparada || this.props.info.fueAdivinada
    return (
      <div
        className="card my-2"
        style={{ width: "125px", height: "125px", background: "none" }}
      >
        <ReactCardFlip
          isFlipped={mostramosCarta}
          flipDirection="horizontal"
        >
          <div
            className="card-body p-0"
            style={stilos.backCard}
            onClick={this.props.seleccionarCarta}
          >
            <p className="card-text">
              <small>React</small>
            </p>
          </div>
          <div
            className="card-body p-0"
            style={stilos.frontCard}
          >
            <i className={`fa ${this.props.info.icono}`}></i>
          </div>
        </ReactCardFlip>
      </div>
    );
  }
}

export default Carta;
