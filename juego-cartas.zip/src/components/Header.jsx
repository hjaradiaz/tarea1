import React from "react";

const Header = ({ intentos, reinciarJuego }) => {

  const handleClick = (e) => {
    e.preventDefault();
    console.log('ejecutnaod');
    reinciarJuego();
  }

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      <p className="navbar-brand">Juego de Cartas</p>
      <div className="navbar-collapse">
        <h3 className="m-auto text-white">intentos: {intentos}</h3>
        <form className="form-inline my-2 my-lg-0">
          <button className="btn btn-light" onClick={handleClick}>Reinciar</button>
        </form>
      </div>
    </nav>
  );
};

export default Header;
